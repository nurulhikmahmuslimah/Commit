

<?php $__env->startSection('title','urutan'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $number; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <H1>Urutan Ke - <?php echo e($number['ke']); ?></H1>
    <H3>Nomor Ke - <?php echo e($number['nomor']); ?></H3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelpertama\resources\views/urutan.blade.php ENDPATH**/ ?>